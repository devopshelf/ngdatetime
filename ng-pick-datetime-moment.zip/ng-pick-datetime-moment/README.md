Angular Date Time Picker MomentJS Adapter
========================

It is MomentJs Adapter for ng-picker-datetime.
You could learn more about this from [here](https://danielykpan.github.io/date-time-picker/).
