import { OwlDateTimeFormats } from 'ng-pick-datetime';
export declare const OWL_MOMENT_DATE_TIME_FORMATS: OwlDateTimeFormats;
