export declare class OwlDialogModule {
}
