import { OwlDateTimeFormats } from '../date-time-format.class';
export declare const OWL_MOMENT_DATE_TIME_FORMATS: OwlDateTimeFormats;
