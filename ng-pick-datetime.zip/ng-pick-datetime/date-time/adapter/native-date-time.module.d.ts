export declare class NativeDateTimeModule {
}
export declare class OwlNativeDateTimeModule {
}
