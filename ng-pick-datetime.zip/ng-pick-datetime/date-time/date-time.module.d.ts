export declare class OwlDateTimeModule {
}
