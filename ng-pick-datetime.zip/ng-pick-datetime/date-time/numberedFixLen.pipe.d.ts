import { PipeTransform } from '@angular/core';
export declare class NumberFixedLenPipe implements PipeTransform {
    transform(num: number, len: number): any;
}
